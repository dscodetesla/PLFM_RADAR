# PLFM_RADAR HF engineering review — iteration 2

**NOT_FOR_MANUFACTURE.** Start with `docs/manufacturing/EMPIRICAL_UNBLOCK.md`.
This is a source recovery/review bundle, not a Gerber fabrication order.

The cumulative binary-safe patch includes both iterations and applies to a CLEAN
checkout of dscodetesla/PLFM_RADAR at:
`749bd0f86a07a28a86347d8ce9c141e601057c40`.
Do not apply it on top of iteration 1 or overwrite unrelated local work.

```bash
git apply --check /absolute/path/to/changes.patch
git apply /absolute/path/to/changes.patch
python3 -m unittest discover -s tools/manufacturing/tests -v
python3 tools/manufacturing/audit.py --strict --output /tmp/plfm-audit.json
```

Expected: 18 manufacturing tests pass; strict audit exits 1 on the still-open
C13/D13 clock mismatch. All four saved SCH/BRD pad/net maps agree. The 50T build
also blocks on that mismatch before creating outputs. Native EAGLE/Vivado review,
full local CI, factory stackup/DFM and physical bring-up remain required.
No commit, push, PR, manufacturer submission or order has been performed.

`corrected/` contains the three corrected BOM/CPL workbooks from iteration 1;
the patch also carries those bytes. Source recovery X36 is in the patch.
Historic iteration-1 evidence is preserved with its own input hashes;
iteration-2 evidence is named explicitly. No hardware validation is implied.
