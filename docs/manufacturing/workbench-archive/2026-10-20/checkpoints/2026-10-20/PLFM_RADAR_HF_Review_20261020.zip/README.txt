PLFM_RADAR HF review package — 2026-10-20
STATUS: NOT_FOR_MANUFACTURE. This is a review patch, not a fabrication ZIP.
Baseline: 749bd0f86a07a28a86347d8ce9c141e601057c40
No remote commit, push, PR, order or payment was performed.

HF_HANDOFF.md: Ukrainian report, evidence, GAP and next actions.
pcbway-requirements.md: per-board factory input contract.
corrected_inputs/: three corrected workbooks for review. Component fit and sourcing NOT approved.
evidence/: baseline/current read-only audit, verification and test logs.
changes.patch: binary-safe patch containing all repository changes, including the workbooks.

Apply from a clean clone at the exact baseline on a topic branch:
  git switch -c fix/hf-manufacturing-audit-20261020 749bd0f86a07a28a86347d8ce9c141e601057c40
  git apply --check /absolute/path/to/changes.patch
  git apply /absolute/path/to/changes.patch
  python3 -m unittest discover -s tools/manufacturing/tests -v
  python3 tools/manufacturing/audit.py --strict --output /tmp/plfm-audit.json

The strict command currently returns 1 for Power X36 board-only. Do not suppress it.
Run every CONTRIBUTING.md CI command with the required allowed installation policy
before committing. ruff and Icarus were unavailable in the authoring environment.
The contribution policy normally targets develop, which has divergent firmware and
older hardware. Selectively port/rebase this narrow patch and rerun tests; do not
blindly merge main into develop or submit a large unrelated diff.

Do not upload these files as an approved fabrication package. Native CAD/XDC fixes,
full CI, per-board stackup and assembly approvals are still required.
